#
# Configuration file for using the XML library in GNOME applications
#
XML2_LIBDIR="-L/usr/local/NDG/lib"
XML2_LIBS="-lxml2 -lz -lpthread  -lm "
XML2_INCLUDEDIR="-I/usr/local/NDG/include/libxml2"
MODULE_VERSION="xml2-2.6.21"

